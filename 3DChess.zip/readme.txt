This software is provided "as is" without express or implied warranty to the extent permitted by applicable law. 

This game files must not be redestribted without my premission.