#define IDC_NEWGAME 201
#define IDC_Continue 202
#define IDC_OPTIONS 203
#define IDC_EXIT 204
#define IDC_CREDITS 205
